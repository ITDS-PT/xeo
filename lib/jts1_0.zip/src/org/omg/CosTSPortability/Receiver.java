
// org/omg/CosTSPortability/Receiver.java

package org.omg.CosTSPortability;

public interface Receiver {

    void received_request(int id, org.omg.CosTransactions.PropagationContext ctx);

    void sending_reply(int id, org.omg.CosTransactions.PropagationContextHolder ctxh);
}
