/*
 * 
 *
 * Copyright (c) 1996 Sun Microsystems, Inc. All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for NON-COMMERCIAL purposes and without fee is hereby
 * granted provided that this copyright notice appears in all copies. Please
 * refer to the file "copyright.html" for further important copyright and
 * licensing information.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE,
 * OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY
 * LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR
 * ITS DERIVATIVES.
 */


package org.omg.CORBA;


/** The TSIdentification interface is defined in the OMG Transactions 
    Service Specification. It provides methods to allow the JTS to register
    its Sender and Receiver interfaces with the ORB. 
    The TSIdentification methods are
    always called from the same address space (i.e. it is a pseudo-object),
    hence it is not necessary to define any stubs/skeletons.
*/

public interface TSIdentification { 

    /** identify_sender is called by the OTS during initialization
        to register its Sender callback interface with the ORB.
        identify_sender may throw a AlreadyIdentified exception if
        the registration has already been done previously.
    */
    public void 
    identify_sender(org.omg.CosTSPortability.Sender senderOTS)
    throws org.omg.CORBA.TSIdentificationPackage.NotAvailable, 
           org.omg.CORBA.TSIdentificationPackage.AlreadyIdentified ;


    /** identify_receiver is called by the OTS during initialization
        to register its Receiver callback interface with the ORB.
        identify_receiver may throw a AlreadyIdentified exception if
        the registration has already been done previously.
    */
    public void 
    identify_receiver(org.omg.CosTSPortability.Receiver receiverOTS)
    throws org.omg.CORBA.TSIdentificationPackage.NotAvailable, 
           org.omg.CORBA.TSIdentificationPackage.AlreadyIdentified ;
}
