
package org.omg.CORBA.TSIdentificationPackage;
public final class AlreadyIdentified
        extends org.omg.CORBA.UserException {
    //  constructor
    public AlreadyIdentified() {
        super();
    }
}

