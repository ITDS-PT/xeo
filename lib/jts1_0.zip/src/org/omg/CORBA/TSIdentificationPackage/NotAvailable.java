
package org.omg.CORBA.TSIdentificationPackage;
public final class NotAvailable
        extends org.omg.CORBA.UserException {
    //  constructor
    public NotAvailable() {
        super();
    }
}

