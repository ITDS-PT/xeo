/*
 * File: SRC/ORG/OMG/COSTRANSACTIONS/_RESOURCESTUB.JAVA
 * From: COSTRANSACTIONS.IDL
 * Date: Fri Mar 13 11:25:30 1998
 *   By: f:\idltojava Java IDL 1.2 Aug 18 1998 16:25:34
 */

package org.omg.CosTransactions;
public class _ResourceStub
	extends org.omg.CORBA.portable.ObjectImpl
    	implements org.omg.CosTransactions.Resource {

    public _ResourceStub(org.omg.CORBA.portable.Delegate d) {
          super();
          _set_delegate(d);
    }

    private static final String _type_ids[] = {
        "IDL:omg.org/CosTransactions/Resource:1.0"
    };

    public String[] _ids() { return (String[]) _type_ids.clone(); }

    //	IDL operations
    //	    Implementation of ::CosTransactions::Resource::prepare
    public org.omg.CosTransactions.Vote prepare()
        throws org.omg.CosTransactions.HeuristicMixed, org.omg.CosTransactions.HeuristicHazard {
           org.omg.CORBA.Request r = _request("prepare");
           r.set_return_type(org.omg.CosTransactions.VoteHelper.type());
           r.exceptions().add(org.omg.CosTransactions.HeuristicMixedHelper.type());
           r.exceptions().add(org.omg.CosTransactions.HeuristicHazardHelper.type());
           r.invoke();
           java.lang.Exception __ex = r.env().exception();
           if (__ex instanceof org.omg.CORBA.UnknownUserException) {
               org.omg.CORBA.UnknownUserException __userEx = (org.omg.CORBA.UnknownUserException) __ex;
               if (__userEx.except.type().equals(org.omg.CosTransactions.HeuristicMixedHelper.type())) {
                   throw org.omg.CosTransactions.HeuristicMixedHelper.extract(__userEx.except);
               }
               if (__userEx.except.type().equals(org.omg.CosTransactions.HeuristicHazardHelper.type())) {
                   throw org.omg.CosTransactions.HeuristicHazardHelper.extract(__userEx.except);
               }
           }
           org.omg.CosTransactions.Vote __result;
           __result = org.omg.CosTransactions.VoteHelper.extract(r.return_value());
           return __result;
   }
    //	    Implementation of ::CosTransactions::Resource::rollback
    public void rollback()
        throws org.omg.CosTransactions.HeuristicCommit, org.omg.CosTransactions.HeuristicMixed, org.omg.CosTransactions.HeuristicHazard {
           org.omg.CORBA.Request r = _request("rollback");
           r.exceptions().add(org.omg.CosTransactions.HeuristicCommitHelper.type());
           r.exceptions().add(org.omg.CosTransactions.HeuristicMixedHelper.type());
           r.exceptions().add(org.omg.CosTransactions.HeuristicHazardHelper.type());
           r.invoke();
           java.lang.Exception __ex = r.env().exception();
           if (__ex instanceof org.omg.CORBA.UnknownUserException) {
               org.omg.CORBA.UnknownUserException __userEx = (org.omg.CORBA.UnknownUserException) __ex;
               if (__userEx.except.type().equals(org.omg.CosTransactions.HeuristicCommitHelper.type())) {
                   throw org.omg.CosTransactions.HeuristicCommitHelper.extract(__userEx.except);
               }
               if (__userEx.except.type().equals(org.omg.CosTransactions.HeuristicMixedHelper.type())) {
                   throw org.omg.CosTransactions.HeuristicMixedHelper.extract(__userEx.except);
               }
               if (__userEx.except.type().equals(org.omg.CosTransactions.HeuristicHazardHelper.type())) {
                   throw org.omg.CosTransactions.HeuristicHazardHelper.extract(__userEx.except);
               }
           }
   }
    //	    Implementation of ::CosTransactions::Resource::commit
    public void commit()
        throws org.omg.CosTransactions.NotPrepared, org.omg.CosTransactions.HeuristicRollback, org.omg.CosTransactions.HeuristicMixed, org.omg.CosTransactions.HeuristicHazard {
           org.omg.CORBA.Request r = _request("commit");
           r.exceptions().add(org.omg.CosTransactions.NotPreparedHelper.type());
           r.exceptions().add(org.omg.CosTransactions.HeuristicRollbackHelper.type());
           r.exceptions().add(org.omg.CosTransactions.HeuristicMixedHelper.type());
           r.exceptions().add(org.omg.CosTransactions.HeuristicHazardHelper.type());
           r.invoke();
           java.lang.Exception __ex = r.env().exception();
           if (__ex instanceof org.omg.CORBA.UnknownUserException) {
               org.omg.CORBA.UnknownUserException __userEx = (org.omg.CORBA.UnknownUserException) __ex;
               if (__userEx.except.type().equals(org.omg.CosTransactions.NotPreparedHelper.type())) {
                   throw org.omg.CosTransactions.NotPreparedHelper.extract(__userEx.except);
               }
               if (__userEx.except.type().equals(org.omg.CosTransactions.HeuristicRollbackHelper.type())) {
                   throw org.omg.CosTransactions.HeuristicRollbackHelper.extract(__userEx.except);
               }
               if (__userEx.except.type().equals(org.omg.CosTransactions.HeuristicMixedHelper.type())) {
                   throw org.omg.CosTransactions.HeuristicMixedHelper.extract(__userEx.except);
               }
               if (__userEx.except.type().equals(org.omg.CosTransactions.HeuristicHazardHelper.type())) {
                   throw org.omg.CosTransactions.HeuristicHazardHelper.extract(__userEx.except);
               }
           }
   }
    //	    Implementation of ::CosTransactions::Resource::commit_one_phase
    public void commit_one_phase()
        throws org.omg.CosTransactions.HeuristicHazard {
           org.omg.CORBA.Request r = _request("commit_one_phase");
           r.exceptions().add(org.omg.CosTransactions.HeuristicHazardHelper.type());
           r.invoke();
           java.lang.Exception __ex = r.env().exception();
           if (__ex instanceof org.omg.CORBA.UnknownUserException) {
               org.omg.CORBA.UnknownUserException __userEx = (org.omg.CORBA.UnknownUserException) __ex;
               if (__userEx.except.type().equals(org.omg.CosTransactions.HeuristicHazardHelper.type())) {
                   throw org.omg.CosTransactions.HeuristicHazardHelper.extract(__userEx.except);
               }
           }
   }
    //	    Implementation of ::CosTransactions::Resource::forget
    public void forget()
 {
           org.omg.CORBA.Request r = _request("forget");
           r.invoke();
   }

};
