/*
 * File: SRC/ORG/OMG/COSTRANSACTIONS/OTID_THELPER.JAVA
 * From: COSTRANSACTIONS.IDL
 * Date: Fri Mar 13 11:25:30 1998
 *   By: f:\idltojava Java IDL 1.2 Aug 18 1998 16:25:34
 */

package org.omg.CosTransactions;
public class otid_tHelper {
     // It is useless to have instances of this class
     private otid_tHelper() { }

    public static void write(org.omg.CORBA.portable.OutputStream out, org.omg.CosTransactions.otid_t that) {
	out.write_long(that.formatID);
	out.write_long(that.bequal_length);
	{
	    out.write_long(that.tid.length);
	    out.write_octet_array(that.tid, 0, that.tid.length);
	}
    }
    public static org.omg.CosTransactions.otid_t read(org.omg.CORBA.portable.InputStream in) {
        org.omg.CosTransactions.otid_t that = new org.omg.CosTransactions.otid_t();
	that.formatID = in.read_long();
	that.bequal_length = in.read_long();
	{
	    int __length = in.read_long();
	    that.tid = new byte[__length];
	    in.read_octet_array(that.tid, 0, that.tid.length);
	}
        return that;
    }
   public static org.omg.CosTransactions.otid_t extract(org.omg.CORBA.Any a) {
     org.omg.CORBA.portable.InputStream in = a.create_input_stream();
     return read(in);
   }
   public static void insert(org.omg.CORBA.Any a, org.omg.CosTransactions.otid_t that) {
     org.omg.CORBA.portable.OutputStream out = a.create_output_stream();
     write(out, that);
     a.read_value(out.create_input_stream(), type());
   }
   private static org.omg.CORBA.TypeCode _tc;
   synchronized public static org.omg.CORBA.TypeCode type() {
       int _memberCount = 3;
       org.omg.CORBA.StructMember[] _members = null;
          if (_tc == null) {
               _members= new org.omg.CORBA.StructMember[3];
               _members[0] = new org.omg.CORBA.StructMember(
                 "formatID",
                 org.omg.CORBA.ORB.init().get_primitive_tc(org.omg.CORBA.TCKind.tk_long),
                 null);

               _members[1] = new org.omg.CORBA.StructMember(
                 "bequal_length",
                 org.omg.CORBA.ORB.init().get_primitive_tc(org.omg.CORBA.TCKind.tk_long),
                 null);

               _members[2] = new org.omg.CORBA.StructMember(
                 "tid",
                 org.omg.CORBA.ORB.init().create_sequence_tc(0, org.omg.CORBA.ORB.init().get_primitive_tc(org.omg.CORBA.TCKind.tk_octet)),
                 null);
             _tc = org.omg.CORBA.ORB.init().create_struct_tc(id(), "otid_t", _members);
          }
      return _tc;
   }
   public static String id() {
       return "IDL:omg.org/CosTransactions/otid_t:1.0";
   }
}
