/*
 * File: SRC/ORG/OMG/COSTRANSACTIONS/SUBTRANSACTIONAWARERESOURCEHOLDER.JAVA
 * From: COSTRANSACTIONS.IDL
 * Date: Fri Mar 13 11:25:30 1998
 *   By: f:\idltojava Java IDL 1.2 Aug 18 1998 16:25:34
 */

package org.omg.CosTransactions;
public final class SubtransactionAwareResourceHolder
     implements org.omg.CORBA.portable.Streamable{
    //	instance variable 
    public org.omg.CosTransactions.SubtransactionAwareResource value;
    //	constructors 
    public SubtransactionAwareResourceHolder() {
	this(null);
    }
    public SubtransactionAwareResourceHolder(org.omg.CosTransactions.SubtransactionAwareResource __arg) {
	value = __arg;
    }

    public void _write(org.omg.CORBA.portable.OutputStream out) {
        org.omg.CosTransactions.SubtransactionAwareResourceHelper.write(out, value);
    }

    public void _read(org.omg.CORBA.portable.InputStream in) {
        value = org.omg.CosTransactions.SubtransactionAwareResourceHelper.read(in);
    }

    public org.omg.CORBA.TypeCode _type() {
        return org.omg.CosTransactions.SubtransactionAwareResourceHelper.type();
    }
}
