/*
 * File: SRC/ORG/OMG/COSTRANSACTIONS/VOTE.JAVA
 * From: COSTRANSACTIONS.IDL
 * Date: Fri Mar 13 11:25:30 1998
 *   By: f:\idltojava Java IDL 1.2 Aug 18 1998 16:25:34
 */

package org.omg.CosTransactions;
public final class Vote implements org.omg.CORBA.portable.IDLEntity {
     public static final int _VoteCommit = 0,
	  		     _VoteRollback = 1,
	  		     _VoteReadOnly = 2;
     public static final Vote VoteCommit = new Vote(_VoteCommit);
     public static final Vote VoteRollback = new Vote(_VoteRollback);
     public static final Vote VoteReadOnly = new Vote(_VoteReadOnly);
     public int value() {
         return _value;
     }
     public static final Vote from_int(int i)  throws  org.omg.CORBA.BAD_PARAM {
           switch (i) {
             case _VoteCommit:
                 return VoteCommit;
             case _VoteRollback:
                 return VoteRollback;
             case _VoteReadOnly:
                 return VoteReadOnly;
             default:
	              throw new org.omg.CORBA.BAD_PARAM();
           }
     }
     private Vote(int _value){
         this._value = _value;
     }
     private int _value;
}
