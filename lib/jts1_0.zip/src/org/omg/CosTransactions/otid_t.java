/*
 * File: SRC/ORG/OMG/COSTRANSACTIONS/OTID_T.JAVA
 * From: COSTRANSACTIONS.IDL
 * Date: Fri Mar 13 11:25:30 1998
 *   By: f:\idltojava Java IDL 1.2 Aug 18 1998 16:25:34
 */

package org.omg.CosTransactions;
public final class otid_t implements org.omg.CORBA.portable.IDLEntity {
    //	instance variables
    public int formatID;
    public int bequal_length;
    public byte[] tid;
    //	constructors
    public otid_t() { }
    public otid_t(int __formatID, int __bequal_length, byte[] __tid) {
	formatID = __formatID;
	bequal_length = __bequal_length;
	tid = __tid;
    }
}
