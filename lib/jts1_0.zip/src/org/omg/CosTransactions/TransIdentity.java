/*
 * File: SRC/ORG/OMG/COSTRANSACTIONS/TRANSIDENTITY.JAVA
 * From: COSTRANSACTIONS.IDL
 * Date: Fri Mar 13 11:25:30 1998
 *   By: f:\idltojava Java IDL 1.2 Aug 18 1998 16:25:34
 */

package org.omg.CosTransactions;
public final class TransIdentity implements org.omg.CORBA.portable.IDLEntity {
    //	instance variables
    public org.omg.CosTransactions.Coordinator coord;
    public org.omg.CosTransactions.Terminator term;
    public org.omg.CosTransactions.otid_t otid;
    //	constructors
    public TransIdentity() { }
    public TransIdentity(org.omg.CosTransactions.Coordinator __coord, org.omg.CosTransactions.Terminator __term, org.omg.CosTransactions.otid_t __otid) {
	coord = __coord;
	term = __term;
	otid = __otid;
    }
}
