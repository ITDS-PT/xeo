/*
 * File: SRC/ORG/OMG/COSTRANSACTIONS/_TRANSACTIONFACTORYSTUB.JAVA
 * From: COSTRANSACTIONS.IDL
 * Date: Fri Mar 13 11:25:30 1998
 *   By: f:\idltojava Java IDL 1.2 Aug 18 1998 16:25:34
 */

package org.omg.CosTransactions;
public class _TransactionFactoryStub
	extends org.omg.CORBA.portable.ObjectImpl
    	implements org.omg.CosTransactions.TransactionFactory {

    public _TransactionFactoryStub(org.omg.CORBA.portable.Delegate d) {
          super();
          _set_delegate(d);
    }

    private static final String _type_ids[] = {
        "IDL:omg.org/CosTransactions/TransactionFactory:1.0"
    };

    public String[] _ids() { return (String[]) _type_ids.clone(); }

    //	IDL operations
    //	    Implementation of ::CosTransactions::TransactionFactory::create
    public org.omg.CosTransactions.Control create(int time_out)
 {
           org.omg.CORBA.Request r = _request("create");
           r.set_return_type(org.omg.CosTransactions.ControlHelper.type());
           org.omg.CORBA.Any _time_out = r.add_in_arg();
           _time_out.insert_ulong(time_out);
           r.invoke();
           org.omg.CosTransactions.Control __result;
           __result = org.omg.CosTransactions.ControlHelper.extract(r.return_value());
           return __result;
   }
    //	    Implementation of ::CosTransactions::TransactionFactory::recreate
    public org.omg.CosTransactions.Control recreate(org.omg.CosTransactions.PropagationContext ctx)
 {
           org.omg.CORBA.Request r = _request("recreate");
           r.set_return_type(org.omg.CosTransactions.ControlHelper.type());
           org.omg.CORBA.Any _ctx = r.add_in_arg();
           org.omg.CosTransactions.PropagationContextHelper.insert(_ctx, ctx);
           r.invoke();
           org.omg.CosTransactions.Control __result;
           __result = org.omg.CosTransactions.ControlHelper.extract(r.return_value());
           return __result;
   }

};
