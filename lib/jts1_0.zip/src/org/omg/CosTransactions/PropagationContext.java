/*
 * File: SRC/ORG/OMG/COSTRANSACTIONS/PROPAGATIONCONTEXT.JAVA
 * From: COSTRANSACTIONS.IDL
 * Date: Fri Mar 13 11:25:30 1998
 *   By: f:\idltojava Java IDL 1.2 Aug 18 1998 16:25:34
 */

package org.omg.CosTransactions;
public final class PropagationContext implements org.omg.CORBA.portable.IDLEntity {
    //	instance variables
    public int timeout;
    public org.omg.CosTransactions.TransIdentity current;
    public org.omg.CosTransactions.TransIdentity[] parents;
    public org.omg.CORBA.Any implementation_specific_data;
    //	constructors
    public PropagationContext() { }
    public PropagationContext(int __timeout, org.omg.CosTransactions.TransIdentity __current, org.omg.CosTransactions.TransIdentity[] __parents, org.omg.CORBA.Any __implementation_specific_data) {
	timeout = __timeout;
	current = __current;
	parents = __parents;
	implementation_specific_data = __implementation_specific_data;
    }
}
