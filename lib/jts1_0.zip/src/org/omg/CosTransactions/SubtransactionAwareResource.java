/*
 * File: SRC/ORG/OMG/COSTRANSACTIONS/SUBTRANSACTIONAWARERESOURCE.JAVA
 * From: COSTRANSACTIONS.IDL
 * Date: Fri Mar 13 11:25:30 1998
 *   By: f:\idltojava Java IDL 1.2 Aug 18 1998 16:25:34
 */

package org.omg.CosTransactions;
public interface SubtransactionAwareResource
    extends org.omg.CORBA.Object, org.omg.CORBA.portable.IDLEntity,
	    org.omg.CosTransactions.Resource {
    void commit_subtransaction(org.omg.CosTransactions.Coordinator parent)
;
    void rollback_subtransaction()
;
}
