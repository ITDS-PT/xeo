/*
 * File: SRC/ORG/OMG/COSTRANSACTIONS/NOTPREPAREDHOLDER.JAVA
 * From: COSTRANSACTIONS.IDL
 * Date: Fri Mar 13 11:25:30 1998
 *   By: f:\idltojava Java IDL 1.2 Aug 18 1998 16:25:34
 */

package org.omg.CosTransactions;
public final class NotPreparedHolder
     implements org.omg.CORBA.portable.Streamable{
    //	instance variable 
    public org.omg.CosTransactions.NotPrepared value;
    //	constructors 
    public NotPreparedHolder() {
	this(null);
    }
    public NotPreparedHolder(org.omg.CosTransactions.NotPrepared __arg) {
	value = __arg;
    }

    public void _write(org.omg.CORBA.portable.OutputStream out) {
        org.omg.CosTransactions.NotPreparedHelper.write(out, value);
    }

    public void _read(org.omg.CORBA.portable.InputStream in) {
        value = org.omg.CosTransactions.NotPreparedHelper.read(in);
    }

    public org.omg.CORBA.TypeCode _type() {
        return org.omg.CosTransactions.NotPreparedHelper.type();
    }
}
