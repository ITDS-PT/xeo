/*
 * File: SRC/ORG/OMG/COSTRANSACTIONS/_CONTROLIMPLBASE.JAVA
 * From: COSTRANSACTIONS.IDL
 * Date: Fri Mar 13 11:25:30 1998
 *   By: f:\idltojava Java IDL 1.2 Aug 18 1998 16:25:34
 */

package org.omg.CosTransactions;
public abstract class _ControlImplBase extends org.omg.CORBA.DynamicImplementation implements org.omg.CosTransactions.Control {
    // Constructor
    public _ControlImplBase() {
         super();
    }
    // Type strings for this class and its superclases
    private static final String _type_ids[] = {
        "IDL:omg.org/CosTransactions/Control:1.0"
    };

    public String[] _ids() { return (String[]) _type_ids.clone(); }

    private static java.util.Dictionary _methods = new java.util.Hashtable();
    static {
      _methods.put("get_terminator", new java.lang.Integer(0));
      _methods.put("get_coordinator", new java.lang.Integer(1));
     }
    // DSI Dispatch call
    public void invoke(org.omg.CORBA.ServerRequest r) {
       switch (((java.lang.Integer) _methods.get(r.op_name())).intValue()) {
           case 0: // org.omg.CosTransactions.Control.get_terminator
              {
              org.omg.CORBA.NVList _list = _orb().create_list(0);
              r.params(_list);
              org.omg.CosTransactions.Terminator ___result;
              try {
                            ___result = this.get_terminator();
              }
              catch (org.omg.CosTransactions.Unavailable e0) {
                            org.omg.CORBA.Any _except = _orb().create_any();
                            org.omg.CosTransactions.UnavailableHelper.insert(_except, e0);
                            r.except(_except);
                            return;
              }
              org.omg.CORBA.Any __result = _orb().create_any();
              org.omg.CosTransactions.TerminatorHelper.insert(__result, ___result);
              r.result(__result);
              }
              break;
           case 1: // org.omg.CosTransactions.Control.get_coordinator
              {
              org.omg.CORBA.NVList _list = _orb().create_list(0);
              r.params(_list);
              org.omg.CosTransactions.Coordinator ___result;
              try {
                            ___result = this.get_coordinator();
              }
              catch (org.omg.CosTransactions.Unavailable e0) {
                            org.omg.CORBA.Any _except = _orb().create_any();
                            org.omg.CosTransactions.UnavailableHelper.insert(_except, e0);
                            r.except(_except);
                            return;
              }
              org.omg.CORBA.Any __result = _orb().create_any();
              org.omg.CosTransactions.CoordinatorHelper.insert(__result, ___result);
              r.result(__result);
              }
              break;
            default:
              throw new org.omg.CORBA.BAD_OPERATION(0, org.omg.CORBA.CompletionStatus.COMPLETED_MAYBE);
       }
 }
}
