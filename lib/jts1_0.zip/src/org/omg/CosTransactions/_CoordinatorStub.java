/*
 * File: SRC/ORG/OMG/COSTRANSACTIONS/_COORDINATORSTUB.JAVA
 * From: COSTRANSACTIONS.IDL
 * Date: Fri Mar 13 11:25:30 1998
 *   By: f:\idltojava Java IDL 1.2 Aug 18 1998 16:25:34
 */

package org.omg.CosTransactions;
public class _CoordinatorStub
	extends org.omg.CORBA.portable.ObjectImpl
    	implements org.omg.CosTransactions.Coordinator {

    public _CoordinatorStub(org.omg.CORBA.portable.Delegate d) {
          super();
          _set_delegate(d);
    }

    private static final String _type_ids[] = {
        "IDL:omg.org/CosTransactions/Coordinator:1.0"
    };

    public String[] _ids() { return (String[]) _type_ids.clone(); }

    //	IDL operations
    //	    Implementation of ::CosTransactions::Coordinator::get_status
    public org.omg.CosTransactions.Status get_status()
 {
           org.omg.CORBA.Request r = _request("get_status");
           r.set_return_type(org.omg.CosTransactions.StatusHelper.type());
           r.invoke();
           org.omg.CosTransactions.Status __result;
           __result = org.omg.CosTransactions.StatusHelper.extract(r.return_value());
           return __result;
   }
    //	    Implementation of ::CosTransactions::Coordinator::get_parent_status
    public org.omg.CosTransactions.Status get_parent_status()
 {
           org.omg.CORBA.Request r = _request("get_parent_status");
           r.set_return_type(org.omg.CosTransactions.StatusHelper.type());
           r.invoke();
           org.omg.CosTransactions.Status __result;
           __result = org.omg.CosTransactions.StatusHelper.extract(r.return_value());
           return __result;
   }
    //	    Implementation of ::CosTransactions::Coordinator::get_top_level_status
    public org.omg.CosTransactions.Status get_top_level_status()
 {
           org.omg.CORBA.Request r = _request("get_top_level_status");
           r.set_return_type(org.omg.CosTransactions.StatusHelper.type());
           r.invoke();
           org.omg.CosTransactions.Status __result;
           __result = org.omg.CosTransactions.StatusHelper.extract(r.return_value());
           return __result;
   }
    //	    Implementation of ::CosTransactions::Coordinator::is_same_transaction
    public boolean is_same_transaction(org.omg.CosTransactions.Coordinator tc)
 {
           org.omg.CORBA.Request r = _request("is_same_transaction");
           r.set_return_type(org.omg.CORBA.ORB.init().get_primitive_tc(org.omg.CORBA.TCKind.tk_boolean));
           org.omg.CORBA.Any _tc = r.add_in_arg();
           org.omg.CosTransactions.CoordinatorHelper.insert(_tc, tc);
           r.invoke();
           boolean __result;
           __result = r.return_value().extract_boolean();
           return __result;
   }
    //	    Implementation of ::CosTransactions::Coordinator::is_related_transaction
    public boolean is_related_transaction(org.omg.CosTransactions.Coordinator tc)
 {
           org.omg.CORBA.Request r = _request("is_related_transaction");
           r.set_return_type(org.omg.CORBA.ORB.init().get_primitive_tc(org.omg.CORBA.TCKind.tk_boolean));
           org.omg.CORBA.Any _tc = r.add_in_arg();
           org.omg.CosTransactions.CoordinatorHelper.insert(_tc, tc);
           r.invoke();
           boolean __result;
           __result = r.return_value().extract_boolean();
           return __result;
   }
    //	    Implementation of ::CosTransactions::Coordinator::is_ancestor_transaction
    public boolean is_ancestor_transaction(org.omg.CosTransactions.Coordinator tc)
 {
           org.omg.CORBA.Request r = _request("is_ancestor_transaction");
           r.set_return_type(org.omg.CORBA.ORB.init().get_primitive_tc(org.omg.CORBA.TCKind.tk_boolean));
           org.omg.CORBA.Any _tc = r.add_in_arg();
           org.omg.CosTransactions.CoordinatorHelper.insert(_tc, tc);
           r.invoke();
           boolean __result;
           __result = r.return_value().extract_boolean();
           return __result;
   }
    //	    Implementation of ::CosTransactions::Coordinator::is_descendant_transaction
    public boolean is_descendant_transaction(org.omg.CosTransactions.Coordinator tc)
 {
           org.omg.CORBA.Request r = _request("is_descendant_transaction");
           r.set_return_type(org.omg.CORBA.ORB.init().get_primitive_tc(org.omg.CORBA.TCKind.tk_boolean));
           org.omg.CORBA.Any _tc = r.add_in_arg();
           org.omg.CosTransactions.CoordinatorHelper.insert(_tc, tc);
           r.invoke();
           boolean __result;
           __result = r.return_value().extract_boolean();
           return __result;
   }
    //	    Implementation of ::CosTransactions::Coordinator::is_top_level_transaction
    public boolean is_top_level_transaction()
 {
           org.omg.CORBA.Request r = _request("is_top_level_transaction");
           r.set_return_type(org.omg.CORBA.ORB.init().get_primitive_tc(org.omg.CORBA.TCKind.tk_boolean));
           r.invoke();
           boolean __result;
           __result = r.return_value().extract_boolean();
           return __result;
   }
    //	    Implementation of ::CosTransactions::Coordinator::hash_transaction
    public int hash_transaction()
 {
           org.omg.CORBA.Request r = _request("hash_transaction");
           r.set_return_type(org.omg.CORBA.ORB.init().get_primitive_tc(org.omg.CORBA.TCKind.tk_ulong));
           r.invoke();
           int __result;
           __result = r.return_value().extract_ulong();
           return __result;
   }
    //	    Implementation of ::CosTransactions::Coordinator::hash_top_level_tran
    public int hash_top_level_tran()
 {
           org.omg.CORBA.Request r = _request("hash_top_level_tran");
           r.set_return_type(org.omg.CORBA.ORB.init().get_primitive_tc(org.omg.CORBA.TCKind.tk_ulong));
           r.invoke();
           int __result;
           __result = r.return_value().extract_ulong();
           return __result;
   }
    //	    Implementation of ::CosTransactions::Coordinator::register_resource
    public org.omg.CosTransactions.RecoveryCoordinator register_resource(org.omg.CosTransactions.Resource rr)
        throws org.omg.CosTransactions.Inactive {
           org.omg.CORBA.Request r = _request("register_resource");
           r.set_return_type(org.omg.CosTransactions.RecoveryCoordinatorHelper.type());
           org.omg.CORBA.Any _rr = r.add_in_arg();
           org.omg.CosTransactions.ResourceHelper.insert(_rr, rr);
           r.exceptions().add(org.omg.CosTransactions.InactiveHelper.type());
           r.invoke();
           java.lang.Exception __ex = r.env().exception();
           if (__ex instanceof org.omg.CORBA.UnknownUserException) {
               org.omg.CORBA.UnknownUserException __userEx = (org.omg.CORBA.UnknownUserException) __ex;
               if (__userEx.except.type().equals(org.omg.CosTransactions.InactiveHelper.type())) {
                   throw org.omg.CosTransactions.InactiveHelper.extract(__userEx.except);
               }
           }
           org.omg.CosTransactions.RecoveryCoordinator __result;
           __result = org.omg.CosTransactions.RecoveryCoordinatorHelper.extract(r.return_value());
           return __result;
   }
    //	    Implementation of ::CosTransactions::Coordinator::register_synchronization
    public void register_synchronization(org.omg.CosTransactions.Synchronization sync)
        throws org.omg.CosTransactions.Inactive, org.omg.CosTransactions.SynchronizationUnavailable {
           org.omg.CORBA.Request r = _request("register_synchronization");
           org.omg.CORBA.Any _sync = r.add_in_arg();
           org.omg.CosTransactions.SynchronizationHelper.insert(_sync, sync);
           r.exceptions().add(org.omg.CosTransactions.InactiveHelper.type());
           r.exceptions().add(org.omg.CosTransactions.SynchronizationUnavailableHelper.type());
           r.invoke();
           java.lang.Exception __ex = r.env().exception();
           if (__ex instanceof org.omg.CORBA.UnknownUserException) {
               org.omg.CORBA.UnknownUserException __userEx = (org.omg.CORBA.UnknownUserException) __ex;
               if (__userEx.except.type().equals(org.omg.CosTransactions.InactiveHelper.type())) {
                   throw org.omg.CosTransactions.InactiveHelper.extract(__userEx.except);
               }
               if (__userEx.except.type().equals(org.omg.CosTransactions.SynchronizationUnavailableHelper.type())) {
                   throw org.omg.CosTransactions.SynchronizationUnavailableHelper.extract(__userEx.except);
               }
           }
   }
    //	    Implementation of ::CosTransactions::Coordinator::register_subtran_aware
    public void register_subtran_aware(org.omg.CosTransactions.SubtransactionAwareResource rr)
        throws org.omg.CosTransactions.Inactive, org.omg.CosTransactions.NotSubtransaction {
           org.omg.CORBA.Request r = _request("register_subtran_aware");
           org.omg.CORBA.Any _rr = r.add_in_arg();
           org.omg.CosTransactions.SubtransactionAwareResourceHelper.insert(_rr, rr);
           r.exceptions().add(org.omg.CosTransactions.InactiveHelper.type());
           r.exceptions().add(org.omg.CosTransactions.NotSubtransactionHelper.type());
           r.invoke();
           java.lang.Exception __ex = r.env().exception();
           if (__ex instanceof org.omg.CORBA.UnknownUserException) {
               org.omg.CORBA.UnknownUserException __userEx = (org.omg.CORBA.UnknownUserException) __ex;
               if (__userEx.except.type().equals(org.omg.CosTransactions.InactiveHelper.type())) {
                   throw org.omg.CosTransactions.InactiveHelper.extract(__userEx.except);
               }
               if (__userEx.except.type().equals(org.omg.CosTransactions.NotSubtransactionHelper.type())) {
                   throw org.omg.CosTransactions.NotSubtransactionHelper.extract(__userEx.except);
               }
           }
   }
    //	    Implementation of ::CosTransactions::Coordinator::rollback_only
    public void rollback_only()
        throws org.omg.CosTransactions.Inactive {
           org.omg.CORBA.Request r = _request("rollback_only");
           r.exceptions().add(org.omg.CosTransactions.InactiveHelper.type());
           r.invoke();
           java.lang.Exception __ex = r.env().exception();
           if (__ex instanceof org.omg.CORBA.UnknownUserException) {
               org.omg.CORBA.UnknownUserException __userEx = (org.omg.CORBA.UnknownUserException) __ex;
               if (__userEx.except.type().equals(org.omg.CosTransactions.InactiveHelper.type())) {
                   throw org.omg.CosTransactions.InactiveHelper.extract(__userEx.except);
               }
           }
   }
    //	    Implementation of ::CosTransactions::Coordinator::get_transaction_name
    public String get_transaction_name()
 {
           org.omg.CORBA.Request r = _request("get_transaction_name");
           r.set_return_type(org.omg.CORBA.ORB.init().get_primitive_tc(org.omg.CORBA.TCKind.tk_string));
           r.invoke();
           String __result;
           __result = r.return_value().extract_string();
           return __result;
   }
    //	    Implementation of ::CosTransactions::Coordinator::create_subtransaction
    public org.omg.CosTransactions.Control create_subtransaction()
        throws org.omg.CosTransactions.SubtransactionsUnavailable, org.omg.CosTransactions.Inactive {
           org.omg.CORBA.Request r = _request("create_subtransaction");
           r.set_return_type(org.omg.CosTransactions.ControlHelper.type());
           r.exceptions().add(org.omg.CosTransactions.SubtransactionsUnavailableHelper.type());
           r.exceptions().add(org.omg.CosTransactions.InactiveHelper.type());
           r.invoke();
           java.lang.Exception __ex = r.env().exception();
           if (__ex instanceof org.omg.CORBA.UnknownUserException) {
               org.omg.CORBA.UnknownUserException __userEx = (org.omg.CORBA.UnknownUserException) __ex;
               if (__userEx.except.type().equals(org.omg.CosTransactions.SubtransactionsUnavailableHelper.type())) {
                   throw org.omg.CosTransactions.SubtransactionsUnavailableHelper.extract(__userEx.except);
               }
               if (__userEx.except.type().equals(org.omg.CosTransactions.InactiveHelper.type())) {
                   throw org.omg.CosTransactions.InactiveHelper.extract(__userEx.except);
               }
           }
           org.omg.CosTransactions.Control __result;
           __result = org.omg.CosTransactions.ControlHelper.extract(r.return_value());
           return __result;
   }
    //	    Implementation of ::CosTransactions::Coordinator::get_txcontext
    public org.omg.CosTransactions.PropagationContext get_txcontext()
        throws org.omg.CosTransactions.Unavailable {
           org.omg.CORBA.Request r = _request("get_txcontext");
           r.set_return_type(org.omg.CosTransactions.PropagationContextHelper.type());
           r.exceptions().add(org.omg.CosTransactions.UnavailableHelper.type());
           r.invoke();
           java.lang.Exception __ex = r.env().exception();
           if (__ex instanceof org.omg.CORBA.UnknownUserException) {
               org.omg.CORBA.UnknownUserException __userEx = (org.omg.CORBA.UnknownUserException) __ex;
               if (__userEx.except.type().equals(org.omg.CosTransactions.UnavailableHelper.type())) {
                   throw org.omg.CosTransactions.UnavailableHelper.extract(__userEx.except);
               }
           }
           org.omg.CosTransactions.PropagationContext __result;
           __result = org.omg.CosTransactions.PropagationContextHelper.extract(r.return_value());
           return __result;
   }

};
