/*
 * File: SRC/ORG/OMG/COSTRANSACTIONS/PROPAGATIONCONTEXTHELPER.JAVA
 * From: COSTRANSACTIONS.IDL
 * Date: Fri Mar 13 11:25:30 1998
 *   By: f:\idltojava Java IDL 1.2 Aug 18 1998 16:25:34
 */

package org.omg.CosTransactions;
public class PropagationContextHelper {
     // It is useless to have instances of this class
     private PropagationContextHelper() { }

    public static void write(org.omg.CORBA.portable.OutputStream out, org.omg.CosTransactions.PropagationContext that) {
	out.write_ulong(that.timeout);
	org.omg.CosTransactions.TransIdentityHelper.write(out, that.current);
	{
	    out.write_long(that.parents.length);
	    for (int __index = 0 ; __index < that.parents.length ; __index += 1) {
	        org.omg.CosTransactions.TransIdentityHelper.write(out, that.parents[__index]);
	    }
	}
	out.write_any(that.implementation_specific_data);
    }
    public static org.omg.CosTransactions.PropagationContext read(org.omg.CORBA.portable.InputStream in) {
        org.omg.CosTransactions.PropagationContext that = new org.omg.CosTransactions.PropagationContext();
	that.timeout = in.read_ulong();
	that.current = org.omg.CosTransactions.TransIdentityHelper.read(in);
	{
	    int __length = in.read_long();
	    that.parents = new org.omg.CosTransactions.TransIdentity[__length];
	    for (int __index = 0 ; __index < that.parents.length ; __index += 1) {
	        that.parents[__index] = org.omg.CosTransactions.TransIdentityHelper.read(in);
	    }
	}
	that.implementation_specific_data = in.read_any();
        return that;
    }
   public static org.omg.CosTransactions.PropagationContext extract(org.omg.CORBA.Any a) {
     org.omg.CORBA.portable.InputStream in = a.create_input_stream();
     return read(in);
   }
   public static void insert(org.omg.CORBA.Any a, org.omg.CosTransactions.PropagationContext that) {
     org.omg.CORBA.portable.OutputStream out = a.create_output_stream();
     write(out, that);
     a.read_value(out.create_input_stream(), type());
   }
   private static org.omg.CORBA.TypeCode _tc;
   synchronized public static org.omg.CORBA.TypeCode type() {
       int _memberCount = 4;
       org.omg.CORBA.StructMember[] _members = null;
          if (_tc == null) {
               _members= new org.omg.CORBA.StructMember[4];
               _members[0] = new org.omg.CORBA.StructMember(
                 "timeout",
                 org.omg.CORBA.ORB.init().get_primitive_tc(org.omg.CORBA.TCKind.tk_ulong),
                 null);

               _members[1] = new org.omg.CORBA.StructMember(
                 "current",
                 org.omg.CosTransactions.TransIdentityHelper.type(),
                 null);

               _members[2] = new org.omg.CORBA.StructMember(
                 "parents",
                 org.omg.CORBA.ORB.init().create_sequence_tc(0, org.omg.CosTransactions.TransIdentityHelper.type()),
                 null);

               _members[3] = new org.omg.CORBA.StructMember(
                 "implementation_specific_data",
                 org.omg.CORBA.ORB.init().get_primitive_tc(org.omg.CORBA.TCKind.tk_any),
                 null);
             _tc = org.omg.CORBA.ORB.init().create_struct_tc(id(), "PropagationContext", _members);
          }
      return _tc;
   }
   public static String id() {
       return "IDL:omg.org/CosTransactions/PropagationContext:1.0";
   }
}
