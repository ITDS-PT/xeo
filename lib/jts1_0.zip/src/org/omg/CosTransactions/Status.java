/*
 * File: SRC/ORG/OMG/COSTRANSACTIONS/STATUS.JAVA
 * From: COSTRANSACTIONS.IDL
 * Date: Fri Mar 13 11:25:30 1998
 *   By: f:\idltojava Java IDL 1.2 Aug 18 1998 16:25:34
 */

package org.omg.CosTransactions;
public final class Status implements org.omg.CORBA.portable.IDLEntity {
     public static final int _StatusActive = 0,
	  		     _StatusMarkedRollback = 1,
	  		     _StatusPrepared = 2,
	  		     _StatusCommitted = 3,
	  		     _StatusRolledBack = 4,
	  		     _StatusUnknown = 5,
	  		     _StatusNoTransaction = 6,
	  		     _StatusPreparing = 7,
	  		     _StatusCommitting = 8,
	  		     _StatusRollingBack = 9;
     public static final Status StatusActive = new Status(_StatusActive);
     public static final Status StatusMarkedRollback = new Status(_StatusMarkedRollback);
     public static final Status StatusPrepared = new Status(_StatusPrepared);
     public static final Status StatusCommitted = new Status(_StatusCommitted);
     public static final Status StatusRolledBack = new Status(_StatusRolledBack);
     public static final Status StatusUnknown = new Status(_StatusUnknown);
     public static final Status StatusNoTransaction = new Status(_StatusNoTransaction);
     public static final Status StatusPreparing = new Status(_StatusPreparing);
     public static final Status StatusCommitting = new Status(_StatusCommitting);
     public static final Status StatusRollingBack = new Status(_StatusRollingBack);
     public int value() {
         return _value;
     }
     public static final Status from_int(int i)  throws  org.omg.CORBA.BAD_PARAM {
           switch (i) {
             case _StatusActive:
                 return StatusActive;
             case _StatusMarkedRollback:
                 return StatusMarkedRollback;
             case _StatusPrepared:
                 return StatusPrepared;
             case _StatusCommitted:
                 return StatusCommitted;
             case _StatusRolledBack:
                 return StatusRolledBack;
             case _StatusUnknown:
                 return StatusUnknown;
             case _StatusNoTransaction:
                 return StatusNoTransaction;
             case _StatusPreparing:
                 return StatusPreparing;
             case _StatusCommitting:
                 return StatusCommitting;
             case _StatusRollingBack:
                 return StatusRollingBack;
             default:
	              throw new org.omg.CORBA.BAD_PARAM();
           }
     }
     private Status(int _value){
         this._value = _value;
     }
     private int _value;
}
