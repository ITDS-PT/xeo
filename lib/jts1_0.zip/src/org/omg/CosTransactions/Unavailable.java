/*
 * File: SRC/ORG/OMG/COSTRANSACTIONS/UNAVAILABLE.JAVA
 * From: COSTRANSACTIONS.IDL
 * Date: Fri Mar 13 11:25:30 1998
 *   By: f:\idltojava Java IDL 1.2 Aug 18 1998 16:25:34
 */

package org.omg.CosTransactions;
public final class Unavailable
	extends org.omg.CORBA.UserException implements org.omg.CORBA.portable.IDLEntity {
    //	constructor
    public Unavailable() {
	super();
    }
}
