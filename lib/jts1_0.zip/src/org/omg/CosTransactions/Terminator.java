/*
 * File: SRC/ORG/OMG/COSTRANSACTIONS/TERMINATOR.JAVA
 * From: COSTRANSACTIONS.IDL
 * Date: Fri Mar 13 11:25:30 1998
 *   By: f:\idltojava Java IDL 1.2 Aug 18 1998 16:25:34
 */

package org.omg.CosTransactions;
public interface Terminator
    extends org.omg.CORBA.Object, org.omg.CORBA.portable.IDLEntity {
    void commit(boolean report_heuristics)
        throws org.omg.CosTransactions.HeuristicMixed, org.omg.CosTransactions.HeuristicHazard;
    void rollback()
;
}
