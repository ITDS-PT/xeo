/*
 * File: SRC/ORG/OMG/COSTRANSACTIONS/UNAVAILABLEHOLDER.JAVA
 * From: COSTRANSACTIONS.IDL
 * Date: Fri Mar 13 11:25:30 1998
 *   By: f:\idltojava Java IDL 1.2 Aug 18 1998 16:25:34
 */

package org.omg.CosTransactions;
public final class UnavailableHolder
     implements org.omg.CORBA.portable.Streamable{
    //	instance variable 
    public org.omg.CosTransactions.Unavailable value;
    //	constructors 
    public UnavailableHolder() {
	this(null);
    }
    public UnavailableHolder(org.omg.CosTransactions.Unavailable __arg) {
	value = __arg;
    }

    public void _write(org.omg.CORBA.portable.OutputStream out) {
        org.omg.CosTransactions.UnavailableHelper.write(out, value);
    }

    public void _read(org.omg.CORBA.portable.InputStream in) {
        value = org.omg.CosTransactions.UnavailableHelper.read(in);
    }

    public org.omg.CORBA.TypeCode _type() {
        return org.omg.CosTransactions.UnavailableHelper.type();
    }
}
