/*
 * File: SRC/ORG/OMG/COSTRANSACTIONS/_SYNCHRONIZATIONSTUB.JAVA
 * From: COSTRANSACTIONS.IDL
 * Date: Fri Mar 13 11:25:30 1998
 *   By: f:\idltojava Java IDL 1.2 Aug 18 1998 16:25:34
 */

package org.omg.CosTransactions;
public class _SynchronizationStub
	extends org.omg.CORBA.portable.ObjectImpl
    	implements org.omg.CosTransactions.Synchronization {

    public _SynchronizationStub(org.omg.CORBA.portable.Delegate d) {
          super();
          _set_delegate(d);
    }

    private static final String _type_ids[] = {
        "IDL:omg.org/CosTransactions/Synchronization:1.0",
        "IDL:omg.org/CosTransactions/TransactionalObject:1.0"
    };

    public String[] _ids() { return (String[]) _type_ids.clone(); }

    //	IDL operations
    //	    Implementation of ::CosTransactions::Synchronization::before_completion
    public void before_completion()
 {
           org.omg.CORBA.Request r = _request("before_completion");
           r.invoke();
   }
    //	    Implementation of ::CosTransactions::Synchronization::after_completion
    public void after_completion(org.omg.CosTransactions.Status status)
 {
           org.omg.CORBA.Request r = _request("after_completion");
           org.omg.CORBA.Any _status = r.add_in_arg();
           org.omg.CosTransactions.StatusHelper.insert(_status, status);
           r.invoke();
   }

};
