/*
 * File: SRC/ORG/OMG/COSTRANSACTIONS/TRANSIDENTITYHOLDER.JAVA
 * From: COSTRANSACTIONS.IDL
 * Date: Fri Mar 13 11:25:30 1998
 *   By: f:\idltojava Java IDL 1.2 Aug 18 1998 16:25:34
 */

package org.omg.CosTransactions;
public final class TransIdentityHolder
     implements org.omg.CORBA.portable.Streamable{
    //	instance variable 
    public org.omg.CosTransactions.TransIdentity value;
    //	constructors 
    public TransIdentityHolder() {
	this(null);
    }
    public TransIdentityHolder(org.omg.CosTransactions.TransIdentity __arg) {
	value = __arg;
    }

    public void _write(org.omg.CORBA.portable.OutputStream out) {
        org.omg.CosTransactions.TransIdentityHelper.write(out, value);
    }

    public void _read(org.omg.CORBA.portable.InputStream in) {
        value = org.omg.CosTransactions.TransIdentityHelper.read(in);
    }

    public org.omg.CORBA.TypeCode _type() {
        return org.omg.CosTransactions.TransIdentityHelper.type();
    }
}
