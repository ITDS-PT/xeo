/*
 * File: SRC/ORG/OMG/COSTRANSACTIONS/RESOURCE.JAVA
 * From: COSTRANSACTIONS.IDL
 * Date: Fri Mar 13 11:25:30 1998
 *   By: f:\idltojava Java IDL 1.2 Aug 18 1998 16:25:34
 */

package org.omg.CosTransactions;
public interface Resource
    extends org.omg.CORBA.Object, org.omg.CORBA.portable.IDLEntity {
    org.omg.CosTransactions.Vote prepare()
        throws org.omg.CosTransactions.HeuristicMixed, org.omg.CosTransactions.HeuristicHazard;
    void rollback()
        throws org.omg.CosTransactions.HeuristicCommit, org.omg.CosTransactions.HeuristicMixed, org.omg.CosTransactions.HeuristicHazard;
    void commit()
        throws org.omg.CosTransactions.NotPrepared, org.omg.CosTransactions.HeuristicRollback, org.omg.CosTransactions.HeuristicMixed, org.omg.CosTransactions.HeuristicHazard;
    void commit_one_phase()
        throws org.omg.CosTransactions.HeuristicHazard;
    void forget()
;
}
