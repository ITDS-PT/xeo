/*
 * File: SRC/ORG/OMG/COSTRANSACTIONS/_TERMINATORSTUB.JAVA
 * From: COSTRANSACTIONS.IDL
 * Date: Fri Mar 13 11:25:30 1998
 *   By: f:\idltojava Java IDL 1.2 Aug 18 1998 16:25:34
 */

package org.omg.CosTransactions;
public class _TerminatorStub
	extends org.omg.CORBA.portable.ObjectImpl
    	implements org.omg.CosTransactions.Terminator {

    public _TerminatorStub(org.omg.CORBA.portable.Delegate d) {
          super();
          _set_delegate(d);
    }

    private static final String _type_ids[] = {
        "IDL:omg.org/CosTransactions/Terminator:1.0"
    };

    public String[] _ids() { return (String[]) _type_ids.clone(); }

    //	IDL operations
    //	    Implementation of ::CosTransactions::Terminator::commit
    public void commit(boolean report_heuristics)
        throws org.omg.CosTransactions.HeuristicMixed, org.omg.CosTransactions.HeuristicHazard {
           org.omg.CORBA.Request r = _request("commit");
           org.omg.CORBA.Any _report_heuristics = r.add_in_arg();
           _report_heuristics.insert_boolean(report_heuristics);
           r.exceptions().add(org.omg.CosTransactions.HeuristicMixedHelper.type());
           r.exceptions().add(org.omg.CosTransactions.HeuristicHazardHelper.type());
           r.invoke();
           java.lang.Exception __ex = r.env().exception();
           if (__ex instanceof org.omg.CORBA.UnknownUserException) {
               org.omg.CORBA.UnknownUserException __userEx = (org.omg.CORBA.UnknownUserException) __ex;
               if (__userEx.except.type().equals(org.omg.CosTransactions.HeuristicMixedHelper.type())) {
                   throw org.omg.CosTransactions.HeuristicMixedHelper.extract(__userEx.except);
               }
               if (__userEx.except.type().equals(org.omg.CosTransactions.HeuristicHazardHelper.type())) {
                   throw org.omg.CosTransactions.HeuristicHazardHelper.extract(__userEx.except);
               }
           }
   }
    //	    Implementation of ::CosTransactions::Terminator::rollback
    public void rollback()
 {
           org.omg.CORBA.Request r = _request("rollback");
           r.invoke();
   }

};
