/*
 * File: SRC/ORG/OMG/COSTRANSACTIONS/_TERMINATORIMPLBASE.JAVA
 * From: COSTRANSACTIONS.IDL
 * Date: Fri Mar 13 11:25:30 1998
 *   By: f:\idltojava Java IDL 1.2 Aug 18 1998 16:25:34
 */

package org.omg.CosTransactions;
public abstract class _TerminatorImplBase extends org.omg.CORBA.DynamicImplementation implements org.omg.CosTransactions.Terminator {
    // Constructor
    public _TerminatorImplBase() {
         super();
    }
    // Type strings for this class and its superclases
    private static final String _type_ids[] = {
        "IDL:omg.org/CosTransactions/Terminator:1.0"
    };

    public String[] _ids() { return (String[]) _type_ids.clone(); }

    private static java.util.Dictionary _methods = new java.util.Hashtable();
    static {
      _methods.put("commit", new java.lang.Integer(0));
      _methods.put("rollback", new java.lang.Integer(1));
     }
    // DSI Dispatch call
    public void invoke(org.omg.CORBA.ServerRequest r) {
       switch (((java.lang.Integer) _methods.get(r.op_name())).intValue()) {
           case 0: // org.omg.CosTransactions.Terminator.commit
              {
              org.omg.CORBA.NVList _list = _orb().create_list(0);
              org.omg.CORBA.Any _report_heuristics = _orb().create_any();
              _report_heuristics.type(org.omg.CORBA.ORB.init().get_primitive_tc(org.omg.CORBA.TCKind.tk_boolean));
              _list.add_value("report_heuristics", _report_heuristics, org.omg.CORBA.ARG_IN.value);
              r.params(_list);
              boolean report_heuristics;
              report_heuristics = _report_heuristics.extract_boolean();
              try {
                            this.commit(report_heuristics);
              }
              catch (org.omg.CosTransactions.HeuristicMixed e0) {
                            org.omg.CORBA.Any _except = _orb().create_any();
                            org.omg.CosTransactions.HeuristicMixedHelper.insert(_except, e0);
                            r.except(_except);
                            return;
              }
              catch (org.omg.CosTransactions.HeuristicHazard e1) {
                            org.omg.CORBA.Any _except = _orb().create_any();
                            org.omg.CosTransactions.HeuristicHazardHelper.insert(_except, e1);
                            r.except(_except);
                            return;
              }
              org.omg.CORBA.Any __return = _orb().create_any();
              __return.type(_orb().get_primitive_tc(org.omg.CORBA.TCKind.tk_void));
              r.result(__return);
              }
              break;
           case 1: // org.omg.CosTransactions.Terminator.rollback
              {
              org.omg.CORBA.NVList _list = _orb().create_list(0);
              r.params(_list);
                            this.rollback();
              org.omg.CORBA.Any __return = _orb().create_any();
              __return.type(_orb().get_primitive_tc(org.omg.CORBA.TCKind.tk_void));
              r.result(__return);
              }
              break;
            default:
              throw new org.omg.CORBA.BAD_OPERATION(0, org.omg.CORBA.CompletionStatus.COMPLETED_MAYBE);
       }
 }
}
