/*
 * File: SRC/ORG/OMG/COSTRANSACTIONS/_TRANSACTIONFACTORYIMPLBASE.JAVA
 * From: COSTRANSACTIONS.IDL
 * Date: Fri Mar 13 11:25:30 1998
 *   By: f:\idltojava Java IDL 1.2 Aug 18 1998 16:25:34
 */

package org.omg.CosTransactions;
public abstract class _TransactionFactoryImplBase extends org.omg.CORBA.DynamicImplementation implements org.omg.CosTransactions.TransactionFactory {
    // Constructor
    public _TransactionFactoryImplBase() {
         super();
    }
    // Type strings for this class and its superclases
    private static final String _type_ids[] = {
        "IDL:omg.org/CosTransactions/TransactionFactory:1.0"
    };

    public String[] _ids() { return (String[]) _type_ids.clone(); }

    private static java.util.Dictionary _methods = new java.util.Hashtable();
    static {
      _methods.put("create", new java.lang.Integer(0));
      _methods.put("recreate", new java.lang.Integer(1));
     }
    // DSI Dispatch call
    public void invoke(org.omg.CORBA.ServerRequest r) {
       switch (((java.lang.Integer) _methods.get(r.op_name())).intValue()) {
           case 0: // org.omg.CosTransactions.TransactionFactory.create
              {
              org.omg.CORBA.NVList _list = _orb().create_list(0);
              org.omg.CORBA.Any _time_out = _orb().create_any();
              _time_out.type(org.omg.CORBA.ORB.init().get_primitive_tc(org.omg.CORBA.TCKind.tk_ulong));
              _list.add_value("time_out", _time_out, org.omg.CORBA.ARG_IN.value);
              r.params(_list);
              int time_out;
              time_out = _time_out.extract_ulong();
              org.omg.CosTransactions.Control ___result;
                            ___result = this.create(time_out);
              org.omg.CORBA.Any __result = _orb().create_any();
              org.omg.CosTransactions.ControlHelper.insert(__result, ___result);
              r.result(__result);
              }
              break;
           case 1: // org.omg.CosTransactions.TransactionFactory.recreate
              {
              org.omg.CORBA.NVList _list = _orb().create_list(0);
              org.omg.CORBA.Any _ctx = _orb().create_any();
              _ctx.type(org.omg.CosTransactions.PropagationContextHelper.type());
              _list.add_value("ctx", _ctx, org.omg.CORBA.ARG_IN.value);
              r.params(_list);
              org.omg.CosTransactions.PropagationContext ctx;
              ctx = org.omg.CosTransactions.PropagationContextHelper.extract(_ctx);
              org.omg.CosTransactions.Control ___result;
                            ___result = this.recreate(ctx);
              org.omg.CORBA.Any __result = _orb().create_any();
              org.omg.CosTransactions.ControlHelper.insert(__result, ___result);
              r.result(__result);
              }
              break;
            default:
              throw new org.omg.CORBA.BAD_OPERATION(0, org.omg.CORBA.CompletionStatus.COMPLETED_MAYBE);
       }
 }
}
