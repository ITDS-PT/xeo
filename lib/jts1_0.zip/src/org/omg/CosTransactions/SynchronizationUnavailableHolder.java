/*
 * File: SRC/ORG/OMG/COSTRANSACTIONS/SYNCHRONIZATIONUNAVAILABLEHOLDER.JAVA
 * From: COSTRANSACTIONS.IDL
 * Date: Fri Mar 13 11:25:30 1998
 *   By: f:\idltojava Java IDL 1.2 Aug 18 1998 16:25:34
 */

package org.omg.CosTransactions;
public final class SynchronizationUnavailableHolder
     implements org.omg.CORBA.portable.Streamable{
    //	instance variable 
    public org.omg.CosTransactions.SynchronizationUnavailable value;
    //	constructors 
    public SynchronizationUnavailableHolder() {
	this(null);
    }
    public SynchronizationUnavailableHolder(org.omg.CosTransactions.SynchronizationUnavailable __arg) {
	value = __arg;
    }

    public void _write(org.omg.CORBA.portable.OutputStream out) {
        org.omg.CosTransactions.SynchronizationUnavailableHelper.write(out, value);
    }

    public void _read(org.omg.CORBA.portable.InputStream in) {
        value = org.omg.CosTransactions.SynchronizationUnavailableHelper.read(in);
    }

    public org.omg.CORBA.TypeCode _type() {
        return org.omg.CosTransactions.SynchronizationUnavailableHelper.type();
    }
}
