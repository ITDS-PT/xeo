/*
 * File: SRC/ORG/OMG/COSTRANSACTIONS/NOTPREPAREDHELPER.JAVA
 * From: COSTRANSACTIONS.IDL
 * Date: Fri Mar 13 11:25:30 1998
 *   By: f:\idltojava Java IDL 1.2 Aug 18 1998 16:25:34
 */

package org.omg.CosTransactions;
public class NotPreparedHelper {
     // It is useless to have instances of this class
     private NotPreparedHelper() { }

    public static void write(org.omg.CORBA.portable.OutputStream out, org.omg.CosTransactions.NotPrepared that) {
    out.write_string(id());
 }
    public static org.omg.CosTransactions.NotPrepared read(org.omg.CORBA.portable.InputStream in) {
        org.omg.CosTransactions.NotPrepared that = new org.omg.CosTransactions.NotPrepared();
         // read and discard the repository id
        in.read_string();
    return that;
    }
   public static org.omg.CosTransactions.NotPrepared extract(org.omg.CORBA.Any a) {
     org.omg.CORBA.portable.InputStream in = a.create_input_stream();
     return read(in);
   }
   public static void insert(org.omg.CORBA.Any a, org.omg.CosTransactions.NotPrepared that) {
     org.omg.CORBA.portable.OutputStream out = a.create_output_stream();
     write(out, that);
     a.read_value(out.create_input_stream(), type());
   }
   private static org.omg.CORBA.TypeCode _tc;
   synchronized public static org.omg.CORBA.TypeCode type() {
       int _memberCount = 0;
       org.omg.CORBA.StructMember[] _members = null;
          if (_tc == null) {
               _members= new org.omg.CORBA.StructMember[0];
             _tc = org.omg.CORBA.ORB.init().create_exception_tc(id(), "NotPrepared", _members);
          }
      return _tc;
   }
   public static String id() {
       return "IDL:omg.org/CosTransactions/NotPrepared:1.0";
   }
}
