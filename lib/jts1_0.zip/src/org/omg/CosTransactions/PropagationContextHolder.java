/*
 * File: SRC/ORG/OMG/COSTRANSACTIONS/PROPAGATIONCONTEXTHOLDER.JAVA
 * From: COSTRANSACTIONS.IDL
 * Date: Fri Mar 13 11:25:30 1998
 *   By: f:\idltojava Java IDL 1.2 Aug 18 1998 16:25:34
 */

package org.omg.CosTransactions;
public final class PropagationContextHolder
     implements org.omg.CORBA.portable.Streamable{
    //	instance variable 
    public org.omg.CosTransactions.PropagationContext value;
    //	constructors 
    public PropagationContextHolder() {
	this(null);
    }
    public PropagationContextHolder(org.omg.CosTransactions.PropagationContext __arg) {
	value = __arg;
    }

    public void _write(org.omg.CORBA.portable.OutputStream out) {
        org.omg.CosTransactions.PropagationContextHelper.write(out, value);
    }

    public void _read(org.omg.CORBA.portable.InputStream in) {
        value = org.omg.CosTransactions.PropagationContextHelper.read(in);
    }

    public org.omg.CORBA.TypeCode _type() {
        return org.omg.CosTransactions.PropagationContextHelper.type();
    }
}
