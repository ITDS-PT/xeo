/*
 * File: SRC/ORG/OMG/COSTRANSACTIONS/RESOURCEHOLDER.JAVA
 * From: COSTRANSACTIONS.IDL
 * Date: Fri Mar 13 11:25:30 1998
 *   By: f:\idltojava Java IDL 1.2 Aug 18 1998 16:25:34
 */

package org.omg.CosTransactions;
public final class ResourceHolder
     implements org.omg.CORBA.portable.Streamable{
    //	instance variable 
    public org.omg.CosTransactions.Resource value;
    //	constructors 
    public ResourceHolder() {
	this(null);
    }
    public ResourceHolder(org.omg.CosTransactions.Resource __arg) {
	value = __arg;
    }

    public void _write(org.omg.CORBA.portable.OutputStream out) {
        org.omg.CosTransactions.ResourceHelper.write(out, value);
    }

    public void _read(org.omg.CORBA.portable.InputStream in) {
        value = org.omg.CosTransactions.ResourceHelper.read(in);
    }

    public org.omg.CORBA.TypeCode _type() {
        return org.omg.CosTransactions.ResourceHelper.type();
    }
}
