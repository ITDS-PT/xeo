/*
 * File: SRC/ORG/OMG/COSTRANSACTIONS/_SYNCHRONIZATIONIMPLBASE.JAVA
 * From: COSTRANSACTIONS.IDL
 * Date: Fri Mar 13 11:25:30 1998
 *   By: f:\idltojava Java IDL 1.2 Aug 18 1998 16:25:34
 */

package org.omg.CosTransactions;
public abstract class _SynchronizationImplBase extends org.omg.CORBA.DynamicImplementation implements org.omg.CosTransactions.Synchronization {
    // Constructor
    public _SynchronizationImplBase() {
         super();
    }
    // Type strings for this class and its superclases
    private static final String _type_ids[] = {
        "IDL:omg.org/CosTransactions/Synchronization:1.0",
        "IDL:omg.org/CosTransactions/TransactionalObject:1.0"
    };

    public String[] _ids() { return (String[]) _type_ids.clone(); }

    private static java.util.Dictionary _methods = new java.util.Hashtable();
    static {
      _methods.put("before_completion", new java.lang.Integer(0));
      _methods.put("after_completion", new java.lang.Integer(1));
     }
    // DSI Dispatch call
    public void invoke(org.omg.CORBA.ServerRequest r) {
       switch (((java.lang.Integer) _methods.get(r.op_name())).intValue()) {
           case 0: // org.omg.CosTransactions.Synchronization.before_completion
              {
              org.omg.CORBA.NVList _list = _orb().create_list(0);
              r.params(_list);
                            this.before_completion();
              org.omg.CORBA.Any __return = _orb().create_any();
              __return.type(_orb().get_primitive_tc(org.omg.CORBA.TCKind.tk_void));
              r.result(__return);
              }
              break;
           case 1: // org.omg.CosTransactions.Synchronization.after_completion
              {
              org.omg.CORBA.NVList _list = _orb().create_list(0);
              org.omg.CORBA.Any _status = _orb().create_any();
              _status.type(org.omg.CosTransactions.StatusHelper.type());
              _list.add_value("status", _status, org.omg.CORBA.ARG_IN.value);
              r.params(_list);
              org.omg.CosTransactions.Status status;
              status = org.omg.CosTransactions.StatusHelper.extract(_status);
                            this.after_completion(status);
              org.omg.CORBA.Any __return = _orb().create_any();
              __return.type(_orb().get_primitive_tc(org.omg.CORBA.TCKind.tk_void));
              r.result(__return);
              }
              break;
            default:
              throw new org.omg.CORBA.BAD_OPERATION(0, org.omg.CORBA.CompletionStatus.COMPLETED_MAYBE);
       }
 }
}
