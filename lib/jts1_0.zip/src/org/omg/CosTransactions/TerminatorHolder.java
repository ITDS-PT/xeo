/*
 * File: SRC/ORG/OMG/COSTRANSACTIONS/TERMINATORHOLDER.JAVA
 * From: COSTRANSACTIONS.IDL
 * Date: Fri Mar 13 11:25:30 1998
 *   By: f:\idltojava Java IDL 1.2 Aug 18 1998 16:25:34
 */

package org.omg.CosTransactions;
public final class TerminatorHolder
     implements org.omg.CORBA.portable.Streamable{
    //	instance variable 
    public org.omg.CosTransactions.Terminator value;
    //	constructors 
    public TerminatorHolder() {
	this(null);
    }
    public TerminatorHolder(org.omg.CosTransactions.Terminator __arg) {
	value = __arg;
    }

    public void _write(org.omg.CORBA.portable.OutputStream out) {
        org.omg.CosTransactions.TerminatorHelper.write(out, value);
    }

    public void _read(org.omg.CORBA.portable.InputStream in) {
        value = org.omg.CosTransactions.TerminatorHelper.read(in);
    }

    public org.omg.CORBA.TypeCode _type() {
        return org.omg.CosTransactions.TerminatorHelper.type();
    }
}
