/*
 * File: SRC/ORG/OMG/COSTRANSACTIONS/_TRANSACTIONALOBJECTSTUB.JAVA
 * From: COSTRANSACTIONS.IDL
 * Date: Fri Mar 13 11:25:30 1998
 *   By: f:\idltojava Java IDL 1.2 Aug 18 1998 16:25:34
 */

package org.omg.CosTransactions;
public class _TransactionalObjectStub
	extends org.omg.CORBA.portable.ObjectImpl
    	implements org.omg.CosTransactions.TransactionalObject {

    public _TransactionalObjectStub(org.omg.CORBA.portable.Delegate d) {
          super();
          _set_delegate(d);
    }

    private static final String _type_ids[] = {
        "IDL:omg.org/CosTransactions/TransactionalObject:1.0"
    };

    public String[] _ids() { return (String[]) _type_ids.clone(); }

    //	IDL operations

};
