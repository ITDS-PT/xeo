/*
 * File: SRC/ORG/OMG/COSTRANSACTIONS/_RECOVERYCOORDINATORIMPLBASE.JAVA
 * From: COSTRANSACTIONS.IDL
 * Date: Fri Mar 13 11:25:30 1998
 *   By: f:\idltojava Java IDL 1.2 Aug 18 1998 16:25:34
 */

package org.omg.CosTransactions;
public abstract class _RecoveryCoordinatorImplBase extends org.omg.CORBA.DynamicImplementation implements org.omg.CosTransactions.RecoveryCoordinator {
    // Constructor
    public _RecoveryCoordinatorImplBase() {
         super();
    }
    // Type strings for this class and its superclases
    private static final String _type_ids[] = {
        "IDL:omg.org/CosTransactions/RecoveryCoordinator:1.0"
    };

    public String[] _ids() { return (String[]) _type_ids.clone(); }

    private static java.util.Dictionary _methods = new java.util.Hashtable();
    static {
      _methods.put("replay_completion", new java.lang.Integer(0));
     }
    // DSI Dispatch call
    public void invoke(org.omg.CORBA.ServerRequest r) {
       switch (((java.lang.Integer) _methods.get(r.op_name())).intValue()) {
           case 0: // org.omg.CosTransactions.RecoveryCoordinator.replay_completion
              {
              org.omg.CORBA.NVList _list = _orb().create_list(0);
              org.omg.CORBA.Any _rr = _orb().create_any();
              _rr.type(org.omg.CosTransactions.ResourceHelper.type());
              _list.add_value("rr", _rr, org.omg.CORBA.ARG_IN.value);
              r.params(_list);
              org.omg.CosTransactions.Resource rr;
              rr = org.omg.CosTransactions.ResourceHelper.extract(_rr);
              org.omg.CosTransactions.Status ___result;
              try {
                            ___result = this.replay_completion(rr);
              }
              catch (org.omg.CosTransactions.NotPrepared e0) {
                            org.omg.CORBA.Any _except = _orb().create_any();
                            org.omg.CosTransactions.NotPreparedHelper.insert(_except, e0);
                            r.except(_except);
                            return;
              }
              org.omg.CORBA.Any __result = _orb().create_any();
              org.omg.CosTransactions.StatusHelper.insert(__result, ___result);
              r.result(__result);
              }
              break;
            default:
              throw new org.omg.CORBA.BAD_OPERATION(0, org.omg.CORBA.CompletionStatus.COMPLETED_MAYBE);
       }
 }
}
