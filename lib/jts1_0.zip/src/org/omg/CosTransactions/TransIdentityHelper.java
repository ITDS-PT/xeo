/*
 * File: SRC/ORG/OMG/COSTRANSACTIONS/TRANSIDENTITYHELPER.JAVA
 * From: COSTRANSACTIONS.IDL
 * Date: Fri Mar 13 11:25:30 1998
 *   By: f:\idltojava Java IDL 1.2 Aug 18 1998 16:25:34
 */

package org.omg.CosTransactions;
public class TransIdentityHelper {
     // It is useless to have instances of this class
     private TransIdentityHelper() { }

    public static void write(org.omg.CORBA.portable.OutputStream out, org.omg.CosTransactions.TransIdentity that) {
	org.omg.CosTransactions.CoordinatorHelper.write(out, that.coord);
	org.omg.CosTransactions.TerminatorHelper.write(out, that.term);
	org.omg.CosTransactions.otid_tHelper.write(out, that.otid);
    }
    public static org.omg.CosTransactions.TransIdentity read(org.omg.CORBA.portable.InputStream in) {
        org.omg.CosTransactions.TransIdentity that = new org.omg.CosTransactions.TransIdentity();
	that.coord = org.omg.CosTransactions.CoordinatorHelper.read(in);
	that.term = org.omg.CosTransactions.TerminatorHelper.read(in);
	that.otid = org.omg.CosTransactions.otid_tHelper.read(in);
        return that;
    }
   public static org.omg.CosTransactions.TransIdentity extract(org.omg.CORBA.Any a) {
     org.omg.CORBA.portable.InputStream in = a.create_input_stream();
     return read(in);
   }
   public static void insert(org.omg.CORBA.Any a, org.omg.CosTransactions.TransIdentity that) {
     org.omg.CORBA.portable.OutputStream out = a.create_output_stream();
     write(out, that);
     a.read_value(out.create_input_stream(), type());
   }
   private static org.omg.CORBA.TypeCode _tc;
   synchronized public static org.omg.CORBA.TypeCode type() {
       int _memberCount = 3;
       org.omg.CORBA.StructMember[] _members = null;
          if (_tc == null) {
               _members= new org.omg.CORBA.StructMember[3];
               _members[0] = new org.omg.CORBA.StructMember(
                 "coord",
                 org.omg.CosTransactions.CoordinatorHelper.type(),
                 null);

               _members[1] = new org.omg.CORBA.StructMember(
                 "term",
                 org.omg.CosTransactions.TerminatorHelper.type(),
                 null);

               _members[2] = new org.omg.CORBA.StructMember(
                 "otid",
                 org.omg.CosTransactions.otid_tHelper.type(),
                 null);
             _tc = org.omg.CORBA.ORB.init().create_struct_tc(id(), "TransIdentity", _members);
          }
      return _tc;
   }
   public static String id() {
       return "IDL:omg.org/CosTransactions/TransIdentity:1.0";
   }
}
