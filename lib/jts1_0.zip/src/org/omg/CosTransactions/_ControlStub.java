/*
 * File: SRC/ORG/OMG/COSTRANSACTIONS/_CONTROLSTUB.JAVA
 * From: COSTRANSACTIONS.IDL
 * Date: Fri Mar 13 11:25:30 1998
 *   By: f:\idltojava Java IDL 1.2 Aug 18 1998 16:25:34
 */

package org.omg.CosTransactions;
public class _ControlStub
	extends org.omg.CORBA.portable.ObjectImpl
    	implements org.omg.CosTransactions.Control {

    public _ControlStub(org.omg.CORBA.portable.Delegate d) {
          super();
          _set_delegate(d);
    }

    private static final String _type_ids[] = {
        "IDL:omg.org/CosTransactions/Control:1.0"
    };

    public String[] _ids() { return (String[]) _type_ids.clone(); }

    //	IDL operations
    //	    Implementation of ::CosTransactions::Control::get_terminator
    public org.omg.CosTransactions.Terminator get_terminator()
        throws org.omg.CosTransactions.Unavailable {
           org.omg.CORBA.Request r = _request("get_terminator");
           r.set_return_type(org.omg.CosTransactions.TerminatorHelper.type());
           r.exceptions().add(org.omg.CosTransactions.UnavailableHelper.type());
           r.invoke();
           java.lang.Exception __ex = r.env().exception();
           if (__ex instanceof org.omg.CORBA.UnknownUserException) {
               org.omg.CORBA.UnknownUserException __userEx = (org.omg.CORBA.UnknownUserException) __ex;
               if (__userEx.except.type().equals(org.omg.CosTransactions.UnavailableHelper.type())) {
                   throw org.omg.CosTransactions.UnavailableHelper.extract(__userEx.except);
               }
           }
           org.omg.CosTransactions.Terminator __result;
           __result = org.omg.CosTransactions.TerminatorHelper.extract(r.return_value());
           return __result;
   }
    //	    Implementation of ::CosTransactions::Control::get_coordinator
    public org.omg.CosTransactions.Coordinator get_coordinator()
        throws org.omg.CosTransactions.Unavailable {
           org.omg.CORBA.Request r = _request("get_coordinator");
           r.set_return_type(org.omg.CosTransactions.CoordinatorHelper.type());
           r.exceptions().add(org.omg.CosTransactions.UnavailableHelper.type());
           r.invoke();
           java.lang.Exception __ex = r.env().exception();
           if (__ex instanceof org.omg.CORBA.UnknownUserException) {
               org.omg.CORBA.UnknownUserException __userEx = (org.omg.CORBA.UnknownUserException) __ex;
               if (__userEx.except.type().equals(org.omg.CosTransactions.UnavailableHelper.type())) {
                   throw org.omg.CosTransactions.UnavailableHelper.extract(__userEx.except);
               }
           }
           org.omg.CosTransactions.Coordinator __result;
           __result = org.omg.CosTransactions.CoordinatorHelper.extract(r.return_value());
           return __result;
   }

};
