/*
 * File: SRC/ORG/OMG/COSTRANSACTIONS/HEURISTICMIXEDHELPER.JAVA
 * From: COSTRANSACTIONS.IDL
 * Date: Fri Mar 13 11:25:30 1998
 *   By: f:\idltojava Java IDL 1.2 Aug 18 1998 16:25:34
 */

package org.omg.CosTransactions;
public class HeuristicMixedHelper {
     // It is useless to have instances of this class
     private HeuristicMixedHelper() { }

    public static void write(org.omg.CORBA.portable.OutputStream out, org.omg.CosTransactions.HeuristicMixed that) {
    out.write_string(id());
 }
    public static org.omg.CosTransactions.HeuristicMixed read(org.omg.CORBA.portable.InputStream in) {
        org.omg.CosTransactions.HeuristicMixed that = new org.omg.CosTransactions.HeuristicMixed();
         // read and discard the repository id
        in.read_string();
    return that;
    }
   public static org.omg.CosTransactions.HeuristicMixed extract(org.omg.CORBA.Any a) {
     org.omg.CORBA.portable.InputStream in = a.create_input_stream();
     return read(in);
   }
   public static void insert(org.omg.CORBA.Any a, org.omg.CosTransactions.HeuristicMixed that) {
     org.omg.CORBA.portable.OutputStream out = a.create_output_stream();
     write(out, that);
     a.read_value(out.create_input_stream(), type());
   }
   private static org.omg.CORBA.TypeCode _tc;
   synchronized public static org.omg.CORBA.TypeCode type() {
       int _memberCount = 0;
       org.omg.CORBA.StructMember[] _members = null;
          if (_tc == null) {
               _members= new org.omg.CORBA.StructMember[0];
             _tc = org.omg.CORBA.ORB.init().create_exception_tc(id(), "HeuristicMixed", _members);
          }
      return _tc;
   }
   public static String id() {
       return "IDL:omg.org/CosTransactions/HeuristicMixed:1.0";
   }
}
