/*
 * File: SRC/ORG/OMG/COSTRANSACTIONS/TERMINATORHELPER.JAVA
 * From: COSTRANSACTIONS.IDL
 * Date: Fri Mar 13 11:25:30 1998
 *   By: f:\idltojava Java IDL 1.2 Aug 18 1998 16:25:34
 */

package org.omg.CosTransactions;
public class TerminatorHelper {
     // It is useless to have instances of this class
     private TerminatorHelper() { }

    public static void write(org.omg.CORBA.portable.OutputStream out, org.omg.CosTransactions.Terminator that) {
        out.write_Object(that);
    }
    public static org.omg.CosTransactions.Terminator read(org.omg.CORBA.portable.InputStream in) {
        return org.omg.CosTransactions.TerminatorHelper.narrow(in.read_Object());
    }
   public static org.omg.CosTransactions.Terminator extract(org.omg.CORBA.Any a) {
     org.omg.CORBA.portable.InputStream in = a.create_input_stream();
     return read(in);
   }
   public static void insert(org.omg.CORBA.Any a, org.omg.CosTransactions.Terminator that) {
     org.omg.CORBA.portable.OutputStream out = a.create_output_stream();
     write(out, that);
     a.read_value(out.create_input_stream(), type());
   }
   private static org.omg.CORBA.TypeCode _tc;
   synchronized public static org.omg.CORBA.TypeCode type() {
          if (_tc == null)
             _tc = org.omg.CORBA.ORB.init().create_interface_tc(id(), "Terminator");
      return _tc;
   }
   public static String id() {
       return "IDL:omg.org/CosTransactions/Terminator:1.0";
   }
   public static org.omg.CosTransactions.Terminator narrow(org.omg.CORBA.Object that)
	    throws org.omg.CORBA.BAD_PARAM {
        if (that == null)
            return null;
        if (that instanceof org.omg.CosTransactions.Terminator)
            return (org.omg.CosTransactions.Terminator) that;
	if (!that._is_a(id())) {
	    throw new org.omg.CORBA.BAD_PARAM();
	}
        org.omg.CORBA.portable.Delegate dup = ((org.omg.CORBA.portable.ObjectImpl)that)._get_delegate();
        org.omg.CosTransactions.Terminator result = new org.omg.CosTransactions._TerminatorStub(dup);
        return result;
   }
}
