/*
 * File: SRC/ORG/OMG/COSTRANSACTIONS/OTID_THOLDER.JAVA
 * From: COSTRANSACTIONS.IDL
 * Date: Fri Mar 13 11:25:30 1998
 *   By: f:\idltojava Java IDL 1.2 Aug 18 1998 16:25:34
 */

package org.omg.CosTransactions;
public final class otid_tHolder
     implements org.omg.CORBA.portable.Streamable{
    //	instance variable 
    public org.omg.CosTransactions.otid_t value;
    //	constructors 
    public otid_tHolder() {
	this(null);
    }
    public otid_tHolder(org.omg.CosTransactions.otid_t __arg) {
	value = __arg;
    }

    public void _write(org.omg.CORBA.portable.OutputStream out) {
        org.omg.CosTransactions.otid_tHelper.write(out, value);
    }

    public void _read(org.omg.CORBA.portable.InputStream in) {
        value = org.omg.CosTransactions.otid_tHelper.read(in);
    }

    public org.omg.CORBA.TypeCode _type() {
        return org.omg.CosTransactions.otid_tHelper.type();
    }
}
