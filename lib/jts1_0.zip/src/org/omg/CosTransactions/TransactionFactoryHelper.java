/*
 * File: SRC/ORG/OMG/COSTRANSACTIONS/TRANSACTIONFACTORYHELPER.JAVA
 * From: COSTRANSACTIONS.IDL
 * Date: Fri Mar 13 11:25:30 1998
 *   By: f:\idltojava Java IDL 1.2 Aug 18 1998 16:25:34
 */

package org.omg.CosTransactions;
public class TransactionFactoryHelper {
     // It is useless to have instances of this class
     private TransactionFactoryHelper() { }

    public static void write(org.omg.CORBA.portable.OutputStream out, org.omg.CosTransactions.TransactionFactory that) {
        out.write_Object(that);
    }
    public static org.omg.CosTransactions.TransactionFactory read(org.omg.CORBA.portable.InputStream in) {
        return org.omg.CosTransactions.TransactionFactoryHelper.narrow(in.read_Object());
    }
   public static org.omg.CosTransactions.TransactionFactory extract(org.omg.CORBA.Any a) {
     org.omg.CORBA.portable.InputStream in = a.create_input_stream();
     return read(in);
   }
   public static void insert(org.omg.CORBA.Any a, org.omg.CosTransactions.TransactionFactory that) {
     org.omg.CORBA.portable.OutputStream out = a.create_output_stream();
     write(out, that);
     a.read_value(out.create_input_stream(), type());
   }
   private static org.omg.CORBA.TypeCode _tc;
   synchronized public static org.omg.CORBA.TypeCode type() {
          if (_tc == null)
             _tc = org.omg.CORBA.ORB.init().create_interface_tc(id(), "TransactionFactory");
      return _tc;
   }
   public static String id() {
       return "IDL:omg.org/CosTransactions/TransactionFactory:1.0";
   }
   public static org.omg.CosTransactions.TransactionFactory narrow(org.omg.CORBA.Object that)
	    throws org.omg.CORBA.BAD_PARAM {
        if (that == null)
            return null;
        if (that instanceof org.omg.CosTransactions.TransactionFactory)
            return (org.omg.CosTransactions.TransactionFactory) that;
	if (!that._is_a(id())) {
	    throw new org.omg.CORBA.BAD_PARAM();
	}
        org.omg.CORBA.portable.Delegate dup = ((org.omg.CORBA.portable.ObjectImpl)that)._get_delegate();
        org.omg.CosTransactions.TransactionFactory result = new org.omg.CosTransactions._TransactionFactoryStub(dup);
        return result;
   }
}
