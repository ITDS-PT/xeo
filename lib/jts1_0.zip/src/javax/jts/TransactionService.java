/*
 * @(#)TransactionService.java	
 *
 * Copyright (c) 1999 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * Copyright Version 1.0
 *
 */

package javax.jts;

import org.omg.CORBA.TSIdentification;
import org.omg.CORBA.ORB;


/**
 * The TransactionService interface is implemented by the JTS Transaction 
 * Manager to allow the ORB to identify itself to the Transaction Manager 
 * and for the Transaction Manager to pass the Sender and Receiver callback 
 * objects to the ORB. The Sender and Receiver objects are used by the ORB 
 * to deliver the user request�s transaction context to the Transaction
 * Manager.
 */

public interface TransactionService {

    /** 
     * identifyORB is called by the ORB to pass on to the Transaction 
     * Manager its TSIdentification object and any custom properties.
     * This allows the Transaction Manager to identify to the ORB the 
     * Sender and Receiver callback objects needed by the ORB when  
     * handling application requests.
     *
     * @param orb A CORBA ORB instance
     * @param tsi A TSIDentification object implemented by the ORB
     * @param prop Properties that contain any custom information 
     */
    public void identifyORB(org.omg.CORBA.ORB orb,
                            org.omg.CORBA.TSIdentification tsi,
                            java.util.Properties prop);

}
